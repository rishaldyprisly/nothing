import paho.mqtt.client as mqtt

user = "rabbit"                    #Connection username
password = "rabbit" 

client = mqtt.Client()
messages = ("name:Rishaldy")


client.username_pw_set(user, password=password)
client.connect("mqtt.flexiot.xl.co.id",1883,60)
client.publish("generic_brand_796generic_devicev1/common", messages);
client.disconnect();